"""
Evan Pham and Rayan Ezedin
10/1
"""

import check_input
import player

def main():
    print("-Yahtzee-")

    The_Player = player.Player()

    while True:
        take_turn(The_Player)
        play_again = check_input.get_yes_no('Play Again? (Y/N) ')
        if play_again == True:
            continue
        elif play_again == False:
            print("Game Over.")
            print('Final Score = ' + str(The_Player.get_points()))
            break
        else:
            print("Invalid input - should be a 'Yes' or 'No'")
            break


def take_turn(player):
    """
    Simulates one turn
    Args:
        player (Player): The player object
    Return:
        None
    """
    player.roll_dice()
    print(player)

    if player.has_three_of_a_kind():
        pass

    elif player.has_series():
        pass
        
    elif player.has_pair():
        pass

    else:
        print('Aww. Too bad') #if there's no value awards

    # if not (player.has_three_of_a_kind() or player.has_series() or player.has_pair()):
    #     print('Aww. Too bad')
    
    print('Score = ' + str(player.get_points()))


main()