import random
class Die:
    """
    A die object with sides and values
    Attributes:
        _sides (int) = Number of sides the die has  
        _value (int) = Current value of the die
    """
    def __init__(self, sides=6):
        """
        Initializes the die object.
        Args:
            _sides (int): The number of sides the die has.
            _value (int): The current value of the die.
        """
        self._sides = sides
        self._value = self.roll()

    def roll(self):
        """
        Rolls the die
        Args:
            self (Die): The die object
        Return:
            An int representing the value of the roll
        """
        self._value = random.randint(1, self._sides)
        return self._value

    def __str__(self):
        """
        A string representation of the die object
        Args:
            self (Die): The die object
        Return:
            An int of the current value of the die
        """
        return str(self._value)

    def __lt__(self, other):
        """
        Checks to see if this die object is less than the other
        Args:
            self (Die): The die object
            other (Die): The other die object
        Return:
            True if this die object has a value less than the other die object, False otherwise
        """
        if isinstance(other, Die):
            return self._value < other._value
        raise TypeError("Can only compare Die objects with other Die objects.")

    def __eq__(self, other):
        """
        Checks to see if two die objects are equal
        Args:
            self (Die): The die object
            other (Die): The other die object
        Return:
            True if the two die objects have the same value, False otherwise
        """
        if isinstance(other, Die):
            return self._value == other._value
        raise TypeError("Can only compare Die objects with other Die objects.")

    def __sub__(self, other):
        """
        Subtracts the value of this die with the other die
        Args:
            self (Die): The die object
            other (Die): The other die object
        Return:
            An int of the difference between this die and the other die
        """
        if isinstance(other, Die):
            return self._value - other._value
        raise TypeError("Can only subtract Die objects with other Die objects. ")
