import die
class Player:
    """
    A player that interacts with dies and gains points.
    Attributes:
        _dice: list of 3 Die objects
        _points: int of player's points
    """
    def __init__(self):
        """
        Initializes the player object.
        Args:
            self (Player): The Player object being initialized
        """
        self._dice = []
        self._points = 0

        for i in range(3):
            self._dice.append(die.Die())

    def get_points(self):
        """
        Gets the player's points.
        Args:
            self (Player): The Player object
        Return:
            The amount of points the player has.
        """

        return self._points
    
    def roll_dice(self):
        """
        Rolls all the player's die.
        Args:
            self (Player): The Player object
        Return:
            None
        """
        
        for die in self._dice:
            die.roll()
        
        self._dice.sort()

    def has_pair(self):
        """
        Detects if player has two dices that have the same value.
        Args:
            self (Player): The Player object
        Return:
            True if there is a pair, False otherise
        """
        
        #check all possible pairings
        if self._dice[0] == self._dice[1] or self._dice[0] == self._dice[2] or self._dice[1] == self._dice[2]:
            self._points += 1
            print("You got a pair!")
            return True
        
        return False

    def has_three_of_a_kind(self):
        """
        Returns true if all three dice in list have the same value
        Args: 
            self (Player): True if player has all three of a kind die 
        Return:
            True if all values are the same, False otherwise
        """

        if self._dice[0] == self._dice[1] == self._dice[2]:
            self._points += 3 #increments score by 3 if valid
            print("You got a three of a kind!")
            return True

        return False  

    def has_series(self):
        """
        Returns true if the values of each of the dice in the list are in sequence
        Args:
            self (Player): True if dice values form a consecutive sequence
        Return:
            True if the player has a series, False otherwise
        """
        values = [self._dice[0], self._dice[1], self._dice[2]] #stores dice values
        
        #checks for a valid sequence
        for i in range(len(values) - 1):
            if values[i+1] - values[i] != 1:
                return False
        
        #increments score by 2 if valid
        self._points += 2
        print("You got a series of 3!")
        return True
            
    def __str__(self):
        """
        Returns a string in a specific format: "D1=2,D2=4, D3=6"
        Args: 
            self (Player): Shows each die's index and respective value
        Return:
            A string displaying all the player's die values
        """
        return f"D1 = {self._dice[0]} D2 = {self._dice[1]} D3 = {self._dice[2]}"